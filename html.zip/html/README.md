# CRM-2.0-2022
This repository will be used for second version of an project known as CRM
 
 Nebeský, Nemna, Šrámek, Štěp, Tran

